/* =====================================================================
   parking_controller.ino      —  ESP32 DevKit v1
   ---------------------------------------------------------------------
   Smart parking model, 3 slots.

   What this board does:
     * Reads 4 ultrasonic sensors — one in the ceiling of each of the 3
       slots, plus one at the entry gate.
     * Decides which slots are free.
     * Hosts a Wi-Fi access point and a web dashboard, so a phone can see
       the slots and choose one.
     * Talks to the self-parking car over Wi-Fi. The car joins this
       board's access point and uses plain HTTP:
           car -> lot   GET /car/event?e=arrived|ack|parked|failed&slot=n
           car -> lot   GET /car/cmd      (reply: NONE, GO:n or STOP)
       The car polls for commands, so a dropped packet just means
       "ask again in half a second". No Bluetooth module is needed.

   No router, no laptop, no internet. The ESP32 is the whole system.

   Wiring and the voltage-divider warning are in the build guide — the
   HC-SR04 ECHO pin puts out 5 V and the ESP32 is a 3.3 V part, so every
   ECHO line MUST go through a divider or you will damage the board.

   Libraries: none beyond the ESP32 core. Install "esp32" by Espressif in
   Arduino IDE → Boards Manager, then pick "ESP32 Dev Module".
   ===================================================================== */

#include <WiFi.h>
#include <WebServer.h>

// ---------------------------------------------------------------- pins
// ECHO pins are 34–39 on purpose: those are input-only on the ESP32,
// which is exactly what an echo line is, and it keeps the output-capable
// pins free. Avoid 0, 2, 12, 15 (strapping) and 6–11 (flash).
const int TRIG_ENTRY = 13,  ECHO_ENTRY = 36;
const int TRIG_SLOT[3] = {14, 27, 26};
const int ECHO_SLOT[3] = {39, 34, 35};
const int LED_SLOT[3]  = {25, 33, 32};   // green = free, off = taken

// (No Bluetooth module any more: the car talks to this board over Wi-Fi.)

// ------------------------------------------------------------- tuning
// Ceiling-to-floor height of the model, in cm. Anything closer than
// (height - CLEARANCE_CM) means something is parked underneath.
const float SLOT_HEIGHT_CM   = 20.0;
const float CLEARANCE_CM     = 7.0;
const float ENTRY_TRIGGER_CM = 15.0;   // car this close to the entry sensor

// A sensor must agree with itself this many times in a row before the
// state changes. Without this, one stray echo makes the dashboard blink.
const int   STABLE_READS     = 4;

const unsigned long SENSE_INTERVAL_MS = 120;
const unsigned long DISPATCH_TIMEOUT_MS = 45000;  // give up if car never arrives
const unsigned long PARKED_HOLD_MS      = 4000;   // show "parked" this long

// ---- autonomous mode: no human taps anything ----
const bool          AUTO_DISPATCH          = true;   // false = dashboard button only
const unsigned long AUTO_DISPATCH_DELAY_MS = 1500;   // car must sit at the gate this long
const unsigned long RETRY_COOLDOWN_MS      = 8000;   // wait after a failed run

// Wi-Fi access point the phone connects to.
const char* AP_SSID = "VIT-SmartParking";
const char* AP_PASS = "park1234";          // >= 8 chars, or the AP won't start

// ---------------------------------------------------------------- state
enum SysState { IDLE, CAR_WAITING, DISPATCHED, PARKING_DONE };
SysState sysState = IDLE;

bool  slotOccupied[3] = {false, false, false};
int   slotAgree[3]    = {0, 0, 0};
bool  slotPending[3]  = {false, false, false};
float slotDist[3]     = {0, 0, 0};

bool  entryBusy   = false;
int   entryAgree  = 0;
bool  entryPending = false;
float entryDist   = 0;

int   assignedSlot = -1;          // 1..3, or -1
unsigned long dispatchedAt = 0;
unsigned long parkedAt     = 0;
String lastCarMsg = "";

unsigned long carWaitingSince    = 0;
unsigned long nextDispatchAllowed = 0;
unsigned long lastCarContact     = 0;     // last time the car sent any request
String carCmd = "NONE";                      // what the car gets when it polls
bool  ackReceived = false;
bool  carArrived  = false;        // car said ARRIVED over the link

WebServer server(80);

// ====================================================== sensor reading
// Returns distance in cm, or -1 if nothing echoed back.
float readOnce(int trigPin, int echoPin) {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(3);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  // 30 ms ≈ 5 m of round trip. Plenty for a tabletop model, and it keeps
  // a missing sensor from stalling the loop.
  unsigned long us = pulseIn(echoPin, HIGH, 30000UL);
  if (us == 0) return -1.0;
  return us / 58.0;
}

// Median of three. One bad reading cannot move the median, which is why
// this beats averaging for ultrasonic noise.
float readDistance(int trigPin, int echoPin) {
  float a = readOnce(trigPin, echoPin); delay(12);
  float b = readOnce(trigPin, echoPin); delay(12);
  float c = readOnce(trigPin, echoPin);

  if (a < 0 && b < 0 && c < 0) return -1.0;
  if (a < 0) a = SLOT_HEIGHT_CM * 2;
  if (b < 0) b = SLOT_HEIGHT_CM * 2;
  if (c < 0) c = SLOT_HEIGHT_CM * 2;

  float hi = max(a, max(b, c));
  float lo = min(a, min(b, c));
  return a + b + c - hi - lo;
}

// Change a boolean state only after STABLE_READS consecutive agreements.
bool debounce(bool reading, bool &state, bool &pending, int &agree) {
  if (reading == state) { agree = 0; return false; }
  if (reading == pending) {
    if (++agree >= STABLE_READS) { state = reading; agree = 0; return true; }
  } else {
    pending = reading;
    agree = 1;
  }
  return false;
}

void senseAll() {
  for (int i = 0; i < 3; i++) {
    slotDist[i] = readDistance(TRIG_SLOT[i], ECHO_SLOT[i]);
    bool occ = (slotDist[i] > 0) && (slotDist[i] < SLOT_HEIGHT_CM - CLEARANCE_CM);
    debounce(occ, slotOccupied[i], slotPending[i], slotAgree[i]);
    digitalWrite(LED_SLOT[i], slotOccupied[i] ? LOW : HIGH);
  }

  entryDist = readDistance(TRIG_ENTRY, ECHO_ENTRY);
  bool atEntry = (entryDist > 0) && (entryDist < ENTRY_TRIGGER_CM);
  debounce(atEntry, entryBusy, entryPending, entryAgree);
}

int freeSlotCount() {
  int n = 0;
  for (int i = 0; i < 3; i++) if (!slotOccupied[i]) n++;
  return n;
}

int firstFreeSlot() {                 // 1-based, or -1
  for (int i = 0; i < 3; i++) if (!slotOccupied[i]) return i + 1;
  return -1;
}

// ================================================= car link (Wi-Fi/HTTP)
// The car asks "any orders?" and we answer with whatever is in carCmd.
// GO:n stays there until the car ACKs, so a lost reply is harmless.
void handleCarCmd() {
  lastCarContact = millis();
  String out = carCmd;
  if (carCmd == "STOP") carCmd = "NONE";    // STOP is delivered once
  server.send(200, "text/plain", out);
}

void handleCarEvent() {
  lastCarContact = millis();
  String e  = server.hasArg("e")    ? server.arg("e")           : "";
  int slot  = server.hasArg("slot") ? server.arg("slot").toInt() : 0;
  lastCarMsg = e + (slot > 0 ? ":" + String(slot) : "");
  Serial.println("<- car: " + lastCarMsg);

  if (e == "arrived") {
    if (sysState == IDLE || sysState == CAR_WAITING) carArrived = true;
  } else if (e == "ack") {
    ackReceived = true;
    if (carCmd.startsWith("GO")) carCmd = "NONE";
  } else if (e == "parked") {
    sysState = PARKING_DONE;
    parkedAt = millis();
  } else if (e == "failed") {
    Serial.println("car reported FAILED; releasing the slot");
    assignedSlot = -1;
    carArrived   = false;
    carCmd       = "NONE";
    sysState     = IDLE;
    nextDispatchAllowed = millis() + RETRY_COOLDOWN_MS;
  }
  server.send(200, "text/plain", "OK");
}

bool dispatchCar(int slot) {          // slot is 1..3
  if (slot < 1 || slot > 3) return false;
  if (slotOccupied[slot - 1])  return false;

  assignedSlot = slot;
  sysState     = DISPATCHED;
  dispatchedAt = millis();
  ackReceived  = false;
  carArrived   = false;
  carCmd       = "GO:" + String(slot);
  Serial.println("-> car: " + carCmd + " (waiting for it to poll)");
  return true;
}

// ======================================================== web dashboard
const char PAGE[] PROGMEM = R"HTML(<!doctype html><html><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Smart Parking</title><style>
:root{--bg:#10151b;--card:#1a222c;--edge:#2b3642;--ink:#e8eef4;--dim:#8d9bab;
      --free:#3ddc84;--busy:#ef5f5f;--accent:#4a9eff}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);
     font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
.w{max-width:620px;margin:0 auto;padding:20px 16px 50px}
h1{font-size:25px;margin:0 0 3px;letter-spacing:-.01em}
.sub{color:var(--dim);font-size:13.5px;margin:0 0 18px}
.banner{background:var(--card);border:1px solid var(--edge);border-left:4px solid var(--accent);
        border-radius:4px;padding:11px 14px;margin-bottom:16px;font-size:14.5px}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:11px}
.slot{background:var(--card);border:1px solid var(--edge);border-radius:6px;
      padding:15px 10px;text-align:center}
.slot.free{border-color:var(--free)}
.slot.busy{opacity:.55}
.num{font-size:30px;font-weight:700;line-height:1}
.st{font-size:11px;letter-spacing:.12em;text-transform:uppercase;margin-top:7px;color:var(--dim)}
.slot.free .st{color:var(--free)} .slot.busy .st{color:var(--busy)}
.cm{font-family:ui-monospace,monospace;font-size:11px;color:var(--dim);margin-top:5px}
button{width:100%;margin-top:11px;padding:9px;border-radius:4px;border:0;cursor:pointer;
       background:var(--accent);color:#04111f;font-weight:600;font-size:13.5px}
button:disabled{background:#2b3642;color:#5d6b7a;cursor:not-allowed}
.foot{margin-top:20px;padding-top:13px;border-top:1px solid var(--edge);
      font-family:ui-monospace,monospace;font-size:11.5px;color:var(--dim)}
</style></head><body><div class="w">
<h1>Smart Parking</h1><p class="sub">3-slot model &middot; ultrasonic sensing</p>
<div class="banner" id="banner">Connecting&hellip;</div>
<div class="grid" id="grid"></div>
<div class="foot" id="foot">&mdash;</div>
</div><script>
function draw(d){
  var g='';
  for(var i=0;i<d.slots.length;i++){
    var s=d.slots[i], free=!s.occupied;
    g+='<div class="slot '+(free?'free':'busy')+'">'
      +'<div class="num">'+s.id+'</div>'
      +'<div class="st">'+(free?'Free':'Taken')+'</div>'
      +'<div class="cm">'+(s.cm<0?'--':s.cm.toFixed(1))+' cm</div>'
      +'<button onclick="go('+s.id+')" '
      +((free && d.car_at_entry && d.state!=='DISPATCHED')?'':'disabled')
      +'>Park here</button></div>';
  }
  document.getElementById('grid').innerHTML=g;

  var b;
  if(d.state==='DISPATCHED') b='Car dispatched to slot '+d.assigned+'. Parking&hellip;';
  else if(d.state==='PARKING_DONE') b='Car parked in slot '+d.assigned+'.';
  else if(d.car_at_entry) b='Car detected at the entry. Assigning the nearest free slot.';
  else if(d.free===0) b='Lot is full.';
  else b=d.free+' of 3 slots free. Waiting for a car at the entry.';
  document.getElementById('banner').textContent=b;

  document.getElementById('foot').textContent =
    'entry '+(d.entry_cm<0?'--':d.entry_cm.toFixed(1))+' cm  |  car says: '+(d.car_msg||'nothing yet')+'  |  car seen '+(d.car_seen_s<0?'never':d.car_seen_s+' s ago');
}
function go(n){
  fetch('/api/assign?slot='+n).then(function(r){return r.json()}).then(function(){tick()});
}
function tick(){
  fetch('/api/status').then(function(r){return r.json()}).then(draw)
    .catch(function(){document.getElementById('banner').textContent='Lost contact with the controller.'});
}
tick(); setInterval(tick,700);
</script></body></html>)HTML";

String stateName() {
  switch (sysState) {
    case IDLE:         return "IDLE";
    case CAR_WAITING:  return "CAR_WAITING";
    case DISPATCHED:   return "DISPATCHED";
    case PARKING_DONE: return "PARKING_DONE";
  }
  return "?";
}

void handleRoot()   { server.send_P(200, "text/html", PAGE); }

void handleStatus() {
  String j = "{\"state\":\"" + stateName() + "\",";
  j += "\"assigned\":" + String(assignedSlot) + ",";
  j += "\"free\":" + String(freeSlotCount()) + ",";
  j += "\"car_at_entry\":" + String(entryBusy ? "true" : "false") + ",";
  j += "\"entry_cm\":" + String(entryDist, 1) + ",";
  j += "\"car_msg\":\"" + lastCarMsg + "\",";
  j += "\"car_seen_s\":" + String(lastCarContact == 0 ? -1L : (long)((millis() - lastCarContact) / 1000)) + ",";
  j += "\"slots\":[";
  for (int i = 0; i < 3; i++) {
    if (i) j += ",";
    j += "{\"id\":" + String(i + 1) +
         ",\"occupied\":" + String(slotOccupied[i] ? "true" : "false") +
         ",\"cm\":" + String(slotDist[i], 1) + "}";
  }
  j += "]}";
  server.send(200, "application/json", j);
}

void handleAssign() {
  int slot = server.hasArg("slot") ? server.arg("slot").toInt() : -1;
  if (slot == 0) slot = firstFreeSlot();          // slot=0 means "pick for me"

  bool ok = dispatchCar(slot);
  server.send(200, "application/json",
              String("{\"ok\":") + (ok ? "true" : "false") +
              ",\"slot\":" + String(slot) + "}");
}

// ================================================================ setup
void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println("\n== Smart Parking controller ==");

  pinMode(TRIG_ENTRY, OUTPUT); digitalWrite(TRIG_ENTRY, LOW);
  pinMode(ECHO_ENTRY, INPUT);
  for (int i = 0; i < 3; i++) {
    pinMode(TRIG_SLOT[i], OUTPUT); digitalWrite(TRIG_SLOT[i], LOW);
    pinMode(ECHO_SLOT[i], INPUT);
    pinMode(LED_SLOT[i], OUTPUT);  digitalWrite(LED_SLOT[i], HIGH);
  }

  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASS);
  Serial.print("AP \""); Serial.print(AP_SSID);
  Serial.print("\"  password "); Serial.println(AP_PASS);
  Serial.print("Dashboard: http://"); Serial.println(WiFi.softAPIP());

  server.on("/",            handleRoot);
  server.on("/api/status",  handleStatus);
  server.on("/api/assign",  handleAssign);
  server.on("/car/cmd",     handleCarCmd);
  server.on("/car/event",   handleCarEvent);
  server.begin();
}

// ================================================================= loop
void loop() {
  server.handleClient();

  static unsigned long lastSense = 0;
  if (millis() - lastSense >= SENSE_INTERVAL_MS) {
    lastSense = millis();
    senseAll();
  }

  switch (sysState) {
    case IDLE:
      if ((entryBusy || carArrived) && freeSlotCount() > 0) {
        sysState = CAR_WAITING;
        carWaitingSince = millis();
      }
      break;

    case CAR_WAITING:
      if (!entryBusy && !carArrived) {
        sysState = IDLE;
      } else if (AUTO_DISPATCH &&
                 millis() >= nextDispatchAllowed &&
                 millis() - carWaitingSince >= AUTO_DISPATCH_DELAY_MS) {
        int s = firstFreeSlot();          // slot 1 is nearest the entry
        if (s > 0) dispatchCar(s);
        else       sysState = IDLE;       // lot filled up while waiting
      }
      break;

    case DISPATCHED:
      // The slot filling up is the real proof the car arrived; the car's
      // own "PARKED" message is only a hint, and it may never come.
      if (assignedSlot > 0 && slotOccupied[assignedSlot - 1]) {
        sysState = PARKING_DONE;
        parkedAt = millis();
      } else if (millis() - dispatchedAt > DISPATCH_TIMEOUT_MS) {
        Serial.println("dispatch timed out; releasing the slot");
        carCmd = "STOP";
        assignedSlot = -1;
        carArrived   = false;
        nextDispatchAllowed = millis() + RETRY_COOLDOWN_MS;
        sysState = IDLE;
      }
      break;

    case PARKING_DONE:
      if (millis() - parkedAt > PARKED_HOLD_MS) {
        assignedSlot = -1;
        sysState = IDLE;
      }
      break;
  }
}
