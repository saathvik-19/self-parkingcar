/* =====================================================================
   parking_car_final.ino   -   ESP32 DevKit on the car (final)
   ---------------------------------------------------------------------
   Hands-off sequence:
     1. Power on, join the lot's Wi-Fi, drive up to the gate line.
     2. Stop there and tell the lot:  arrived
     3. The lot sees the car and replies "GO:n" when the car polls it.
     4. Car drives straight down the corridor and stops when the FRONT
        sensor reads the distance stored for slot n (the pre-mapped route).
     5. Servo swings to the side and checks that the slot opening is there.
     6. Car turns right into the slot, creeps until the back wall is
        PARK_CM away, tells the lot "parked".

   Why distance and not time: battery charge, floor friction and motor
   mismatch change how far a timed run goes. A distance reading to the end
   wall does not care about any of that.

   Wi-Fi protocol (lot is 192.168.4.1):
     GET /car/cmd                       -> "NONE", "GO:n" or "STOP"
     GET /car/event?e=arrived           car is at the gate
     GET /car/event?e=ack&slot=n        heard GO:n
     GET /car/event?e=parked&slot=n     stopped inside slot n
     GET /car/event?e=failed&slot=n     gave up (n=0: never reached the gate)

   Hardware notes for this build
     * No resistors? Power the HC-SR04 from the ESP32's 3V3 pin. Then ECHO only
       swings to 3.3 V and goes straight to GPIO 34. If you do have a 1k + 2k
       pair, power the sensor from 5 V (VIN) and put the divider on ECHO.
     * No capacitor? SOFT_START below ramps the motors up gradually so they do
       not yank the supply down all at once (that is what resets an ESP32).
       Best fix of all: power the ESP32 from a power bank over USB and use the
       battery pack for the motors only, with the grounds joined.

   Libraries: "ESP32Servo" (Library Manager). Wi-Fi and HTTPClient come
   with the ESP32 core. Board: "ESP32 Dev Module".

   Every value under "calibrate me" must be measured on your own model.
   Set CALIBRATE_ONLY = true first: the car will not drive, it just prints
   the front and side distances so you can read the numbers off.
   ===================================================================== */

#include <WiFi.h>
#include <HTTPClient.h>
#include <ESP32Servo.h>

// ---------------------------------------------------------------- pins
// Avoid 0, 2, 12, 15 (boot straps) and 6-11 (flash). 34-39 are input only,
// which is what an echo line should be.
const int ENA = 25, IN1 = 26, IN2 = 27;     // left side motors
const int ENB = 13, IN3 = 32, IN4 = 33;     // right side motors
const int SERVO_PIN = 18;
const int TRIG = 19;
const int ECHO = 34;                        // direct if the sensor runs on 3V3,
                                            // through a 1k + 2k divider if it runs on 5 V

// Motor PWM settings (LEDC)
const int PWM_FREQ = 1000;                  // Hz
const int PWM_BITS = 8;                     // duty 0-255
const int CH_ENA = 4, CH_ENB = 5;           // only used on core 2.x

// ------------------------------------------------------------- network
const char* WIFI_SSID = "VIT-SmartParking";
const char* WIFI_PASS = "park1234";
const char* LOT_URL   = "http://192.168.4.1";

// ------------------------------------------------------- calibrate me
const bool  CALIBRATE_ONLY = false;         // true = just print distances

const int SERVO_FORWARD = 90;               // angle that looks straight ahead
const int SERVO_SIDE    = 175;              // angle that looks at the slots. It must be
                                            // the SAME side the car turns toward (right).
                                            // If it looks left on your car, use 5.

const int DRIVE_SPEED = 170;                // 0-255
const int CREEP_SPEED = 120;
const int TURN_SPEED  = 170;
const bool SOFT_START = true;               // ramp motor speed up instead of a hard kick
const int  RAMP_STEP  = 40;                 // speed added per step (0-255 scale)
const unsigned long RAMP_MS = 30;           // time between steps (0 to 170 takes ~150 ms)
const int LEFT_TRIM   = 0;                  // trim ADDS speed to that side. If the car veers
const int RIGHT_TRIM  = 0;                  //   LEFT, raise LEFT_TRIM; veers RIGHT, raise RIGHT_TRIM

// Distances are the FRONT sensor's reading to the wall at the far end of
// the corridor, in cm. Park the car at each position and read them off
// with CALIBRATE_ONLY. Slot 1 is nearest the gate, so it has the biggest value.
const float GATE_FRONT_CM       = 130.0;    // gate line (where the car waits)
const float SLOT_FRONT_CM[3]    = {100.0, 70.0, 40.0};  // car centred on slot 1, 2, 3
const float SLOWDOWN_CM         = 15.0;     // switch to creep this far before target
const float PAST_TOLERANCE_CM   = 8.0;      // already this far past the slot = fail

const float OPENING_CM  = 30.0;             // side reading above this = open slot
const bool  VERIFY_SLOT = true;             // check the opening before turning in
const int   VERIFY_STEPS   = 5;             // creeps allowed while searching for it
const unsigned long VERIFY_STEP_MS = 120;

const float PARK_CM     = 8.0;              // stop this far from the slot's back wall
const unsigned long TURN_90_MS      = 1400; // time for a 90 degree spin (700 was too short in the ramp test)
const unsigned long BOOT_DELAY_MS   = 3000;
const unsigned long WIFI_TIMEOUT_MS = 20000;
const unsigned long NAV_TIMEOUT_MS  = 45000;

// --------------------------------------------------------------- state
enum CarState { CONNECTING, APPROACH_GATE, AT_GATE, GOTO_SLOT, VERIFY,
                TURNING, ENTERING, PARKED, FAILED, IDLE };
CarState state = CONNECTING;

Servo scanner;
int   targetSlot   = 0;
int   verifyTries  = 0;
int   hits         = 0;                     // consecutive "reached target" readings
int   badReads     = 0;                     // consecutive missing echoes
unsigned long stateStarted = 0;
unsigned long navStarted   = 0;
unsigned long lastPoll     = 0;
unsigned long lastArrived  = 0;
unsigned long lastPrint    = 0;

// ======================================================== motor control
void pwmWrite(int pin, int ch, int duty) {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(pin, duty);                     // core 3.x: channel is picked for us
#else
  ledcWrite(ch, duty);                      // core 2.x
#endif
}

void pwmBegin() {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(ENA, PWM_FREQ, PWM_BITS);
  ledcAttach(ENB, PWM_FREQ, PWM_BITS);
#else
  ledcSetup(CH_ENA, PWM_FREQ, PWM_BITS); ledcAttachPin(ENA, CH_ENA);
  ledcSetup(CH_ENB, PWM_FREQ, PWM_BITS); ledcAttachPin(ENB, CH_ENB);
#endif
}

int trimmed(int speed, int trim) {          // keep the sign, nudge the size
  if (speed == 0) return 0;
  int mag = constrain(abs(speed) + trim, 0, 255);
  return speed > 0 ? mag : -mag;
}

int curL = 0, curR = 0;                     // what the motors are actually getting now

// Speeding up is gradual, slowing down and stopping are instant.
int rampSide(int cur, int target, bool stepNow) {
  if (!SOFT_START || target == 0) return target;
  int sign = target > 0 ? 1 : -1;
  int mag  = abs(target);
  int curMag = (cur * sign > 0) ? abs(cur) : 0;   // only count speed in the same direction
  if (curMag >= mag) return target;
  if (!stepNow) return sign * curMag;
  return sign * min(mag, curMag + RAMP_STEP);
}

void drive(int left, int right) {           // -255..255, negative = reverse
  static unsigned long lastStep = 0;
  bool stepNow = millis() - lastStep >= RAMP_MS;
  if (stepNow) lastStep = millis();

  left  = rampSide(curL, trimmed(left,  LEFT_TRIM),  stepNow);
  right = rampSide(curR, trimmed(right, RIGHT_TRIM), stepNow);
  curL = left; curR = right;

  digitalWrite(IN1, left  > 0); digitalWrite(IN2, left  < 0);
  digitalWrite(IN3, right > 0); digitalWrite(IN4, right < 0);
  pwmWrite(ENA, CH_ENA, abs(left));
  pwmWrite(ENB, CH_ENB, abs(right));
}

// Hold a speed for a fixed time. Calls drive() repeatedly so the ramp can run.
void driveFor(int left, int right, unsigned long ms) {
  unsigned long t0 = millis();
  while (millis() - t0 < ms) { drive(left, right); delay(10); }
}

void halt()           { drive(0, 0); }
void forward(int s)   { drive(s, s); }
void spinRight(int s) { drive(s, -s); }

// ====================================================== sensor reading
// One ping in cm, or -1 for "no echo". A dropout must not count as
// "far", or the car thinks it found an opening that is not there.
float pingOnce() {
  digitalWrite(TRIG, LOW);  delayMicroseconds(3);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  unsigned long us = pulseIn(ECHO, HIGH, 25000UL);
  if (us == 0) return -1.0;
  return us / 58.0;
}

// Median of three valid pings. One stray echo cannot move the median.
float readCm() {
  float v[3]; int n = 0;
  for (int i = 0; i < 3; i++) {
    float d = pingOnce();
    if (d > 0) v[n++] = d;
    delay(8);
  }
  if (n == 0) return -1.0;
  if (n == 1) return v[0];
  if (n == 2) return min(v[0], v[1]);
  float hi = max(v[0], max(v[1], v[2]));
  float lo = min(v[0], min(v[1], v[2]));
  return v[0] + v[1] + v[2] - hi - lo;
}

void look(int angle, int settleMs = 300) { scanner.write(angle); delay(settleMs); }

// ===================================================== link to the lot
bool httpGet(const String &path, String *body = nullptr) {
  if (WiFi.status() != WL_CONNECTED) return false;
  HTTPClient http;
  http.setConnectTimeout(600);
  http.setTimeout(800);
  http.begin(String(LOT_URL) + path);
  int code = http.GET();
  if (code == 200 && body) { *body = http.getString(); body->trim(); }
  http.end();
  return code == 200;
}

bool sendEvent(const char* e, int slot) {   // retry, because Wi-Fi drops packets
  String path = String("/car/event?e=") + e + "&slot=" + String(slot);
  for (int i = 0; i < 3; i++) {
    if (httpGet(path)) { Serial.println(String("-> ") + e + ":" + String(slot)); return true; }
    delay(150);
  }
  Serial.println(String("!! could not send ") + e);
  return false;
}

void enter(CarState s) { state = s; stateStarted = millis(); hits = 0; badReads = 0; }

void fail(const char* why) {
  halt();
  Serial.println(String("FAILED: ") + why);
  look(SERVO_FORWARD, 200);
  sendEvent("failed", targetSlot);
  enter(FAILED);
}

// Ask the lot for orders. Only called while the car is standing still,
// because a Wi-Fi request can block for most of a second.
void pollCommand() {
  String cmd;
  if (!httpGet("/car/cmd", &cmd)) return;
  if (cmd.startsWith("GO:")) {
    int slot = cmd.substring(3).toInt();
    if (slot < 1 || slot > 3) return;
    targetSlot = slot;
    navStarted = millis();
    verifyTries = 0;
    sendEvent("ack", slot);
    Serial.println("GO slot " + String(slot) + ", target front " +
                   String(SLOT_FRONT_CM[slot - 1]) + " cm");
    enter(GOTO_SLOT);
  } else if (cmd.startsWith("STOP")) {
    halt();
    enter(IDLE);
  }
}

// True once the reading has been at-or-below the target twice in a row.
bool reached(float front, float target) {
  if (front > 0 && front <= target) hits++; else hits = 0;
  return hits >= 2;
}

// Returns true if the echo has been missing for too long to keep driving blind.
bool lostSensor(float front) {
  if (front < 0) badReads++; else badReads = 0;
  return badReads > 12;
}

// ================================================================ setup
void setup() {
  Serial.begin(115200);
  delay(300);

  pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  pinMode(TRIG, OUTPUT); digitalWrite(TRIG, LOW);
  pinMode(ECHO, INPUT);
  pwmBegin();
  halt();

  scanner.setPeriodHertz(50);
  scanner.attach(SERVO_PIN, 500, 2400);
  scanner.write(SERVO_FORWARD);

  if (CALIBRATE_ONLY) {
    Serial.println("CALIBRATE_ONLY: not driving. Move the car by hand and read the numbers.");
    return;
  }

  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);                     // lower latency, more reliable polling
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.print("Joining " + String(WIFI_SSID));
  stateStarted = millis();
}

// ================================================================= loop
void loop() {
  if (CALIBRATE_ONLY) {
    look(SERVO_FORWARD);
    float front = readCm();
    look(SERVO_SIDE);
    float side = readCm();
    Serial.println("front " + String(front, 1) + " cm   side " + String(side, 1) + " cm");
    return;
  }

  // Safety net while running a slot route.
  if ((state == GOTO_SLOT || state == VERIFY || state == TURNING || state == ENTERING) &&
      millis() - navStarted > NAV_TIMEOUT_MS) {
    fail("route timed out");
    return;
  }

  switch (state) {

    case CONNECTING:
      if (WiFi.status() == WL_CONNECTED) {
        Serial.println("\nconnected, IP " + WiFi.localIP().toString());
        Serial.println("leaving for the gate in 3 s");
        delay(BOOT_DELAY_MS);
        enter(APPROACH_GATE);
      } else if (millis() - stateStarted > WIFI_TIMEOUT_MS) {
        Serial.println("\nno Wi-Fi: is the lot powered, and are SSID/password right?");
        stateStarted = millis();
        WiFi.disconnect(); WiFi.begin(WIFI_SSID, WIFI_PASS);
      } else {
        Serial.print("."); delay(400);
      }
      break;

    // Drive straight until the front sensor says we are at the gate line.
    case APPROACH_GATE: {
      float front = readCm();
      if (lostSensor(front)) { fail("front sensor lost its echo"); break; }
      if (reached(front, GATE_FRONT_CM)) {
        halt();
        Serial.println("at the gate, front = " + String(front, 1) + " cm");
        sendEvent("arrived", 0);
        lastArrived = millis();
        enter(AT_GATE);
      } else {
        forward((front > 0 && front < GATE_FRONT_CM + SLOWDOWN_CM) ? CREEP_SPEED : DRIVE_SPEED);
      }
      break;
    }

    // Stand still, keep asking for orders, and repeat "arrived" in case it was lost.
    case AT_GATE:
      halt();
      if (WiFi.status() != WL_CONNECTED) { WiFi.reconnect(); delay(500); break; }
      if (millis() - lastPoll > 400) { lastPoll = millis(); pollCommand(); }
      if (state == AT_GATE && millis() - lastArrived > 3000) {
        sendEvent("arrived", 0); lastArrived = millis();
      }
      break;

    // The pre-mapped route: drive until the front distance matches this slot.
    case GOTO_SLOT: {
      float target = SLOT_FRONT_CM[targetSlot - 1];
      float front  = readCm();
      if (lostSensor(front)) { fail("front sensor lost its echo"); break; }

      if (front > 0 && front < target - PAST_TOLERANCE_CM) {
        fail("already past the slot");
        break;
      }
      if (reached(front, target)) {
        halt();
        Serial.println("reached slot " + String(targetSlot) + ", front = " + String(front, 1));
        look(SERVO_SIDE);                   // now look at the slot opening
        verifyTries = 0;
        enter(VERIFY);
      } else {
        forward((front > 0 && front < target + SLOWDOWN_CM) ? CREEP_SPEED : DRIVE_SPEED);
      }
      break;
    }

    // Dead reckoning got us here; the side sensor confirms it.
    case VERIFY: {
      if (!VERIFY_SLOT) { look(SERVO_FORWARD); enter(TURNING); break; }
      float side = readCm();
      Serial.println("side = " + String(side, 1) + " cm");
      if (side > OPENING_CM) {
        look(SERVO_FORWARD);
        enter(TURNING);
      } else if (verifyTries++ < VERIFY_STEPS) {
        driveFor(CREEP_SPEED, CREEP_SPEED, VERIFY_STEP_MS); halt(); delay(150);
      } else {
        fail("no opening found beside the car");
      }
      break;
    }

    case TURNING:
      spinRight(TURN_SPEED);
      if (millis() - stateStarted > TURN_90_MS) {
        halt();
        delay(200);
        enter(ENTERING);
      }
      break;

    // Creep into the slot until the back wall is PARK_CM ahead.
    case ENTERING: {
      float front = readCm();
      if (lostSensor(front)) { fail("front sensor lost its echo"); break; }
      if (reached(front, PARK_CM)) {
        halt();
        Serial.println("parked, front = " + String(front, 1) + " cm");
        sendEvent("parked", targetSlot);
        enter(PARKED);
      } else {
        forward(CREEP_SPEED);
      }
      break;
    }

    case PARKED:
    case FAILED:
    case IDLE:
      halt();
      break;
  }
}
